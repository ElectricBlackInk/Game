| Milestone #   | Member Initials | Brief Description  |
| :-----------: |:---------------:|:-----------------: |
| M1            | SE              | Drafted minutes &  |
|               |                 | Plan, set up       |
|               |                 | milestone doucment.|
|               |                 | Commented in       |
|               |                 | sections, & began  |
|               |                 | research for setUp.|
| M2            | SE              | Drafted new plan   |
|               |                 | docs, set up game  |
|               |                 | board, and helped  |
|               |                 | orient buttons     |
|               |                 |                    | 
|               |                 |                    |
|               |                 |                    |
|               |                 |                    |
